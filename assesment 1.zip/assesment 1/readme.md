# design are given in design folder
![screen shot](./design/desktop-design.jpg "screen shot")

# mobile ui
![screen shot](./design/mobile-design.jpg "screen shot")

